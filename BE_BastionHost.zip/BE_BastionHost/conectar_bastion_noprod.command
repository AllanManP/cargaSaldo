#!/bin/bash
ssh root@172.24.110.115 -i /Users/allanmanriquezpoblete/Desktop/BE_BastionHost/BE_Bastionhost_noprod -D 9300 -N -o ServerAliveInterval=30


