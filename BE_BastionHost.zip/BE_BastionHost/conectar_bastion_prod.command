#!/bin/bash
ssh root@172.24.62.76 -i BE_Bastionhost_Prod -D 9301 -N -o ServerAliveInterval=30
