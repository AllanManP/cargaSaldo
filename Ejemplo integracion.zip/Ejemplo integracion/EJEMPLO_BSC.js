const axios = require('axios');
const { error } = require('console');
const crypto = require('crypto');
const fs = require('fs');
const util = require('util');
const QRCode = require('qrcode'); 
const uuid = require('uuid-v4');
 
const PRI_KEY_FS_UTF8 = fs.readFileSync('./rsa_keys/sample_rsa_private_key.pem', 'utf8');
const PUB_KEY_FS_UTF8 = fs.readFileSync('./rsa_keys/sample_rsa_public_key.pem', 'utf8');
// Función para firmar datos (equivalente a la función sign en Java)
function sign(payload, privateKey) {
    try {
        //console.log("================payLoad content===========================");
        //console.log({ payload });
        //console.log("================payLoad content===========================\n");
        //const sign = crypto.createSign('SHA256');
        const sign = crypto.createSign('RSA-SHA256');
        sign.update(payload);
        sign.end();
        const signature = sign.sign(
            {
                key: privateKey
            },
            'base64'
        );
        return signature;
    } catch (error) {
        throw new Error(error);
    }
}
// Función para verificar la firma
function verifySignature(payload, signature, publicKey, algorithm = 'SHA256withRSA') {
    try {
        //const verify = crypto.createVerify('SHA256');
        const verify = crypto.createVerify('RSA-SHA256');
        verify.update(payload);
        verify.end();
        const isValid = verify.verify(publicKey, signature, 'base64');
        return isValid;
    } catch (error) {
        throw new Error(error);
    }
}
// Función principal
function main() {
    //ClientId
    const clientId = "2025090380655373791341";
    const httpMethod = "POST";
    const uriWithQueryString = "/v1/payments/retailPay";
    const timeString = "2024-08-19T10:26:21+08:00";
    const content = `{
                "productCode": "51051000101000100040",
                "paymentRequestId": "${uuid()}", //el comercio arma este id unico por cada pago, para idenfiticar la transaccion luego con sus sistemas
                "paymentAuthCode": "123456", //código estático de ejemplo, debe ir el escaneado del cliente
                "paymentAmount": {
                    "currency": "CLP",
                    "value": "1000"
                },
                "order": {
                    "orderDescription": "Compra Rutpay",
                    "transactionAddress": "Calle esperanza 123",       
                },
                "paymentNotifyUrl": ""
            }`;
    // La misma línea importante de Java, para construir el payload
    //const payload = `${httpMethod} ${uriWithQueryString}\n${clientId}.${timeString}.${content}`;
    //Codigo Java ->>>>> exmaple entegado /// arriba no queda igual q el output del java de jdoodle el primer object
    //String payload = String.format("%s %s\n%s.%s.%s", httpMethod, uriWithQueryString, clientId, timeString, content);
    // Formatear la cadena para firmar
    const payloadString = util.format('%s %s\n%s.%s.%s',
        httpMethod,
        uriWithQueryString,
        clientId,
        timeString,
        content,
    );
    //console.log({ payloadString });
 
    // Firmamos el payload
    const signResult = sign(payloadString, PRI_KEY_FS_UTF8);
    console.log("================body content===========================");
    console.log({ content });
    console.log("================body content===========================\n");
    //console.log("================signature content===========================");
    //console.log({ signResult });
    //console.log("================signature content===========================\n");
    // Verificamos la firma
    const isSignatureValid = verifySignature(payloadString, signResult, PUB_KEY_FS_UTF8);
    console.log("Firma válida:", isSignatureValid);
 
    //POST REQUEST TO CIRRUS
    const API_CIRRUS_URI_CREATE_ORDER = "https://desa-uat-cirrus.bancoestado.cl/v1/payments/retailPay";
    const headers = {
        'Client-Id': clientId,
        'Request-Time': timeString,
        'Signature': `algorithm=SHA256withRSA,keyVersion=0,signature=${signResult}`,
        'Content-Type': 'application/json'
    };
    console.log({ headers });
    axios.post(
        API_CIRRUS_URI_CREATE_ORDER,
        content, {
        headers: headers
    })
        .then(response => {
            console.log("Response from Cirrus API:");
            console.log(response.data);
        })
        .catch(error => {
            console.error("Error calling Cirrus API:");
            console.error(error);
        });
    }

 

// Ejecutar la función principal
main()