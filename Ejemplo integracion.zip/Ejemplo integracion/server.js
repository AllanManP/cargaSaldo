const axios = require('axios');
const { error } = require('console');
const crypto = require('crypto');
const fs = require('fs');
const util = require('util');
const QRCode = require('qrcode'); 
const uuid = require('uuid-v4');
 
// Pem COMPRAAQUIII
// const PRI_KEY_FS_UTF8 = fs.readFileSync('rsa_keys/compraaqui_rsa_private_key.pem', 'utf8');
// const PUB_KEY_FS_UTF8 = fs.readFileSync('rsa_keys/compraaqui_rsa_public_key.pem', 'utf8');
 
// Pem Daniel confirmar el clientId (?)
const PRI_KEY_FS_UTF8 = fs.readFileSync('./rsa_keys/sample_rsa_private_key.pem', 'utf8');
const PUB_KEY_FS_UTF8 = fs.readFileSync('./rsa_keys/sample_rsa_public_key.pem', 'utf8');
// Función para firmar datos (equivalente a la función sign en Java)
function sign(payload, privateKey) {
    try {
        //console.log("================payLoad content===========================");
        //console.log({ payload });
        //console.log("================payLoad content===========================\n");
        //const sign = crypto.createSign('SHA256');
        const sign = crypto.createSign('RSA-SHA256');
        sign.update(payload);
        sign.end();
        const signature = sign.sign(
            {
                key: privateKey
            },
            'base64'
        );
        return signature;
    } catch (error) {
        throw new Error(error);
    }
}
// Función para verificar la firma
function verifySignature(payload, signature, publicKey, algorithm = 'SHA256withRSA') {
    try {
        //const verify = crypto.createVerify('SHA256');
        const verify = crypto.createVerify('RSA-SHA256');
        verify.update(payload);
        verify.end();
        const isValid = verify.verify(publicKey, signature, 'base64');
        return isValid;
    } catch (error) {
        throw new Error(error);
    }
}
// Función principal
function main() {
    //ClientId
    const clientId = "2025090380655373791341";
    const httpMethod = "POST";
    const uriWithQueryString = "/v1/payments/createQrOrder";
    const timeString = "2024-08-19T10:26:21+08:00";
    const content = `{
        "productCode": "51051000101000100048",
        "bizType": "ORDER_CODE",
        "codeType": "EMVCo",
        "paymentNotifyUrl": "http://10.18.0.102/mock/api/v1/payments/notifyPayment.htm",
        "order": {
            "orderAmount": {
                "currency": "CLP",
                "value": "100000"
            },
            "merchantTransId": "${uuid()}",
            "orderTitle": "orderTitle",
            "transactionAddress": "transactionAddress"
        }
    }`;
    // La misma línea importante de Java, para construir el payload
    //const payload = `${httpMethod} ${uriWithQueryString}\n${clientId}.${timeString}.${content}`;
    //Codigo Java ->>>>> exmaple entegado /// arriba no queda igual q el output del java de jdoodle el primer object
    //String payload = String.format("%s %s\n%s.%s.%s", httpMethod, uriWithQueryString, clientId, timeString, content);
    // Formatear la cadena para firmar
    const payloadString = util.format('%s %s\n%s.%s.%s',
        httpMethod,
        uriWithQueryString,
        clientId,
        timeString,
        content,
    );
    console.log('Payload String',{ payloadString });
 
    // Firmamos el payload
    const signResult = sign(payloadString, PRI_KEY_FS_UTF8);
    console.log("================body content===========================");
    console.log({ content });
    console.log("================body content===========================\n");
    //console.log("================signature content===========================");
    //console.log({ signResult });
    //console.log("================signature content===========================\n");
    // Verificamos la firma
    const isSignatureValid = verifySignature(payloadString, signResult, PUB_KEY_FS_UTF8);
    console.log("Firma válida:", isSignatureValid);
 
    //POST REQUEST TO CIRRUS
    const API_CIRRUS_URI_CREATE_QR = "https://desa-uat-cirrus.bancoestado.cl/v1/payments/createQrOrder";
    const headers = {
        'Client-Id': clientId,
        'Request-Time': timeString,
        'Signature': `algorithm=SHA256withRSA,keyVersion=0,signature=${signResult}`,
        'Content-Type': 'application/json'
    };
    console.log({ headers });
    axios.post(
        API_CIRRUS_URI_CREATE_QR,
        content, {
        headers: headers
    })
        .then(response => {
            console.log("Response from Cirrus API:");
            console.log(response.data);
            const qrCodeString = response.data.qrCode;
            generateQRCode(qrCodeString);
            //const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${response.data.qrCode}`;
        })
        .catch(error => {
            console.error("Error calling Cirrus API:");
            console.error(error);
        });
    }

        function generateQRCode(qrCodeString) {
            console.error(qrCodeString)
            return QRCode.toString(qrCodeString, {
               errorCorrectLevel: '',
               type: 'terminal',
               renderer: {
                width: '10',
                height: '10'
              }
             }, 
              
            function (err, url) {
              if (err) {
                console.error(err);
                console.error('Error Status:', err.response.status);
                console.error('Error Data:', err.response.data);
                //console.error('Error Headers:', err.response.headers);
                } else {
                console.log(url);
                //return url;
                // console.error('Error Message:', err.message);
                  // Si se quiere guardar el qr como imagen
                  // qrCode.toFile('qr-code.png');
              }
            });
          }
 

// Ejecutar la función principal
main()